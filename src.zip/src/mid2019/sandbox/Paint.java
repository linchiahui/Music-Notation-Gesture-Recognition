package mid2019.sandbox;

import mid2019.graphicsLib.Window;

import java.awt.*;


public class Paint extends Window {

  public Paint() {
    super("Paint", 1000, 500);
  }

  @Override
  protected void paintComponent(Graphics g) {
    super.paintComponent(g);

  }
}
